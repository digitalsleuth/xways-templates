# X-Ways Templates

This is a curated collection of X-Ways Templates from various sources.  
The authors of these templates are identified in each template where possible, however if you happen to know of the author of a template and it's not identified here, raise an issue and let me know so it can be corrected.  


